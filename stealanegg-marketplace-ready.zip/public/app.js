const tg=window.Telegram?.WebApp;
if(tg){tg.ready();tg.expand();}
const state={tab:"market",game:"All",q:"",listings:[],orders:[],me:null};
const app=document.getElementById("app");
const api=async(path,opt={})=>{
  const h={"content-type":"application/json","x-telegram-init-data":tg?.initData||""};
  const r=await fetch(path,{...opt,headers:{...h,...(opt.headers||{})}});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(d.error||"Ошибка");
  return d;
};
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function refresh(){try{state.me=await api("/api/me");document.getElementById("balance").textContent=`${state.me.user.balance} ⭐`; }catch(e){}}
function money(n){return `${n} ⭐`}
async function market(){
 state.listings=await api(`/api/listings?game=${encodeURIComponent(state.game==="All"?"":state.game)}&q=${encodeURIComponent(state.q)}`);
 app.innerHTML=`<div class="title">Marketplace</div>
 <input class="search" id="q" placeholder="Поиск товара..." value="${esc(state.q)}">
 <div class="filters">${["All","Roblox","Standoff 2"].map(x=>`<button class="${state.game===x?"active":""}" data-g="${x}">${x}</button>`).join("")}</div>
 ${state.listings.map(x=>`<div class="card"><div class="row"><span class="muted">${esc(x.game)}</span><b>${money(x.price)}</b></div><h3>${esc(x.title)}</h3><div class="muted">${esc(x.info||"")}</div><p>${esc(x.description||"")}</p><div class="muted">Продавец: @${esc(x.seller_username||"unknown")} · ${esc(x.created_at)}</div><button class="primary" onclick="buy(${x.id})">Купить</button></div>`).join("")||`<div class="card">Товаров пока нет.</div>`}`;
 document.getElementById("q").oninput=e=>{state.q=e.target.value;clearTimeout(window.qt);window.qt=setTimeout(market,350)};
 document.querySelectorAll("[data-g]").forEach(b=>b.onclick=()=>{state.game=b.dataset.g;market()});
}
async function buy(id){
 if(!confirm("Купить этот товар?"))return;
 try{const d=await api("/api/orders",{method:"POST",body:JSON.stringify({listingId:id})});alert(`Заказ #${d.orderId} создан.`);state.tab="chat";render()}catch(e){alert(e.message)}
}
async function topup(){
 const n=Number(prompt("Сколько Stars пополнить?"));
 if(!Number.isInteger(n)||n<1)return;
 try{const d=await api("/api/topup/invoice",{method:"POST",body:JSON.stringify({stars:n})});if(tg?.openInvoice)tg.openInvoice(d.url,()=>refresh());else window.open(d.url,"_blank")}catch(e){alert(e.message)}
}
async function sell(){
 app.innerHTML=`<div class="title">Продать товар</div>
 <div class="card"><input id="title" class="input" placeholder="Название товара"><div class="tabs"><button id="rob">Roblox</button><button id="st">Standoff 2</button></div>
 <input id="tag" class="input" placeholder="Gamer Tag / ID"><input id="info" class="input" placeholder="Краткая информация"><textarea id="desc" class="input textarea" placeholder="Описание"></textarea><input id="img" class="input" placeholder="Ссылка на изображение"><input id="price" class="input" type="number" placeholder="Цена в Stars"><button class="primary" id="pub">Опубликовать</button></div>`;
 let game="Roblox";rob.onclick=()=>game="Roblox";st.onclick=()=>game="Standoff 2";
 pub.onclick=async()=>{try{await api("/api/listings",{method:"POST",body:JSON.stringify({game,title:title.value,info:info.value,description:desc.value,gamer_tag:tag.value,image:img.value,price:Number(price.value)})});alert("Товар опубликован");state.tab="market";render()}catch(e){alert(e.message)}}
}
async function chats(){
 state.orders=await api("/api/orders");
 app.innerHTML=`<div class="title">Заказы и чаты</div>${state.orders.map(o=>`<div class="card"><div class="row"><b>#${o.id} ${esc(o.title)}</b><span>${money(o.price)}</span></div><div class="muted">${esc(o.game)} · ${esc(o.status)}</div><button class="primary" onclick="openOrder(${o.id})">Открыть чат</button></div>`).join("")||`<div class="card">Заказов пока нет.</div>`}`;
}
async function openOrder(id){
 const o=state.orders.find(x=>x.id===id)||{};
 const msgs=await api(`/api/orders/${id}/messages`);
 app.innerHTML=`<div class="title">Заказ #${id}</div><div class="card"><b>${esc(o.title)}</b><p>${esc(o.game)} · ${money(o.price)}</p><div class="notice">Статус: ${esc(o.status)}</div>${msgs.map(m=>`<div class="card"><b>${m.sender_id===state.me.user.id?"Вы":"Пользователь"}</b><p>${esc(m.text)}</p></div>`).join("")}<textarea id="msg" class="input textarea" placeholder="Сообщение"></textarea><button class="primary" id="send">Отправить</button>${o.buyer_id===state.me.user.id&&o.status!=="completed"?`<button class="primary" id="received">✓ Я получил товар</button>`:""}<button class="primary danger" id="dispute">Проблема / Dispute</button></div>`;
 send.onclick=async()=>{if(msg.value.trim()){await api(`/api/orders/${id}/messages`,{method:"POST",body:JSON.stringify({text:msg.value})});openOrder(id)}};
 if(document.getElementById("received"))received.onclick=async()=>{if(confirm("Подтвердить получение товара?")){await api(`/api/orders/${id}/received`,{method:"POST"});openOrder(id)}};
 dispute.onclick=async()=>{await api(`/api/orders/${id}/dispute`,{method:"POST"});openOrder(id)};
}
async function profile(){
 await refresh();
 app.innerHTML=`<div class="title">Профиль</div><div class="card"><h3>@${esc(state.me.user.username||"user")}</h3><p>ID: ${state.me.user.id}</p><p>Баланс: <b>${money(state.me.user.balance)}</b></p><p>Покупок: ${state.me.purchases}</p><p>Продаж: ${state.me.sales}</p><button class="primary" onclick="topup()">⭐ Пополнить Stars</button></div><div class="card"><h3>Поддержка</h3><button class="primary" onclick="ticket()">Создать обращение</button></div>`;
}
async function ticket(){
 const subject=prompt("Тема"); if(!subject)return; const text=prompt("Опишите проблему"); if(!text)return;
 try{await api("/api/tickets",{method:"POST",body:JSON.stringify({subject,text})});alert("Обращение создано")}catch(e){alert(e.message)}
}
async function render(){await refresh();if(state.tab==="market")return market();if(state.tab==="sell")return sell();if(state.tab==="chat")return chats();return profile()}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;render()});
document.getElementById("support").onclick=()=>ticket();
render();