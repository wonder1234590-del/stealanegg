import express from "express";
import dotenv from "dotenv";
import crypto from "crypto";
import Database from "better-sqlite3";

dotenv.config();
const app = express();
const db = new Database("marketplace.db");
const PORT = Number(process.env.PORT || 3000);
const BOT_TOKEN = process.env.BOT_TOKEN || "";
const ADMIN_IDS = new Set((process.env.ADMIN_IDS || "").split(",").map(x => x.trim()).filter(Boolean));

app.use(express.json({ limit: "2mb" }));
app.use(express.static("public"));

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY,
  username TEXT,
  first_name TEXT,
  balance INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS listings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  seller_id INTEGER NOT NULL,
  seller_username TEXT,
  game TEXT NOT NULL CHECK(game IN ('Roblox','Standoff 2')),
  title TEXT NOT NULL,
  info TEXT,
  description TEXT,
  gamer_tag TEXT,
  image TEXT,
  price INTEGER NOT NULL CHECK(price > 0),
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  listing_id INTEGER NOT NULL,
  buyer_id INTEGER NOT NULL,
  seller_id INTEGER NOT NULL,
  price INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'waiting_seller',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TEXT
);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL,
  sender_id INTEGER NOT NULL,
  text TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  payload TEXT NOT NULL UNIQUE,
  stars INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  telegram_charge_id TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ledger(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  type TEXT NOT NULL,
  ref TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tickets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  subject TEXT NOT NULL,
  text TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id INTEGER,
  action TEXT NOT NULL,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

function telegramUserFromInitData(initData) {
  if (!BOT_TOKEN || !initData) return null;
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return null;
  params.delete("hash");
  const pairs = [...params.entries()].sort((a,b) => a[0].localeCompare(b[0])).map(([k,v]) => `${k}=${v}`);
  const secret = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  const check = crypto.createHmac("sha256", secret).update(pairs.join("\n")).digest("hex");
  if (!crypto.timingSafeEqual(Buffer.from(check), Buffer.from(hash))) return null;
  const user = params.get("user");
  return user ? JSON.parse(user) : null;
}

function auth(req, res, next) {
  const user = telegramUserFromInitData(req.headers["x-telegram-init-data"] || "");
  if (!user) return res.status(401).json({ error: "Откройте приложение из Telegram." });
  db.prepare(`
    INSERT INTO users(id, username, first_name) VALUES(?,?,?)
    ON CONFLICT(id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name
  `).run(user.id, user.username || "", user.first_name || "");
  req.tgUser = user;
  next();
}

function sendBotMessage(chatId, text) {
  if (!BOT_TOKEN) return;
  fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: "POST",
    headers: {"content-type":"application/json"},
    body: JSON.stringify({ chat_id: chatId, text })
  }).catch(()=>{});
}

app.get("/api/me", auth, (req,res)=>{
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(req.tgUser.id);
  const purchases = db.prepare("SELECT COUNT(*) c FROM orders WHERE buyer_id=? AND status='completed'").get(u.id).c;
  const sales = db.prepare("SELECT COUNT(*) c FROM orders WHERE seller_id=? AND status='completed'").get(u.id).c;
  res.json({ user:u, purchases, sales });
});

app.get("/api/listings", (req,res)=>{
  const game = req.query.game;
  const q = String(req.query.q || "").trim();
  let sql = "SELECT * FROM listings WHERE status='active'";
  const args = [];
  if (game && ["Roblox","Standoff 2"].includes(game)) { sql += " AND game=?"; args.push(game); }
  if (q) { sql += " AND (title LIKE ? OR description LIKE ? OR seller_username LIKE ?)"; const x=`%${q}%`; args.push(x,x,x); }
  sql += " ORDER BY id DESC";
  res.json(db.prepare(sql).all(...args));
});

app.post("/api/listings", auth, (req,res)=>{
  const {game,title,info,description,gamer_tag,image,price} = req.body || {};
  if (!["Roblox","Standoff 2"].includes(game)) return res.status(400).json({error:"Только Roblox или Standoff 2."});
  if (!title || !Number.isInteger(Number(price)) || Number(price) <= 0) return res.status(400).json({error:"Проверьте название и цену."});
  const r = db.prepare(`
    INSERT INTO listings(seller_id,seller_username,game,title,info,description,gamer_tag,image,price)
    VALUES(?,?,?,?,?,?,?,?,?)
  `).run(req.tgUser.id, req.tgUser.username || "", game, title, info||"", description||"", gamer_tag||"", image||"", Number(price));
  res.json({ok:true,id:r.lastInsertRowid});
});

app.delete("/api/listings/:id", auth, (req,res)=>{
  const r = db.prepare("UPDATE listings SET status='removed' WHERE id=? AND seller_id=? AND status='active'").run(req.params.id, req.tgUser.id);
  res.json({ok:r.changes>0});
});

app.post("/api/topup/invoice", auth, async (req,res)=>{
  const stars = Number(req.body?.stars);
  if (!Number.isInteger(stars) || stars < 1 || stars > 100000) return res.status(400).json({error:"Некорректное количество Stars."});
  if (!BOT_TOKEN) return res.status(500).json({error:"BOT_TOKEN не настроен."});
  const payload = `topup:${req.tgUser.id}:${crypto.randomUUID()}`;
  db.prepare("INSERT INTO payments(user_id,payload,stars) VALUES(?,?,?)").run(req.tgUser.id,payload,stars);
  const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/createInvoiceLink`, {
    method:"POST", headers:{"content-type":"application/json"},
    body: JSON.stringify({
      title:"Пополнение баланса",
      description:`Пополнение внутреннего баланса на ${stars} Stars`,
      payload,
      currency:"XTR",
      prices:[{label:"Stars",amount:stars}]
    })
  });
  const data = await response.json();
  if (!data.ok) return res.status(500).json({error:"Telegram не создал счёт.", details:data.description});
  res.json({url:data.result});
});

app.post("/api/orders", auth, (req,res)=>{
  const listingId = Number(req.body?.listingId);
  const tx = db.transaction(() => {
    const listing = db.prepare("SELECT * FROM listings WHERE id=?").get(listingId);
    if (!listing || listing.status !== "active") throw new Error("Товар уже недоступен.");
    if (listing.seller_id === req.tgUser.id) throw new Error("Нельзя купить свой товар.");
    const buyer = db.prepare("SELECT * FROM users WHERE id=?").get(req.tgUser.id);
    if (buyer.balance < listing.price) throw new Error("Недостаточно Stars на внутреннем балансе.");
    const locked = db.prepare("UPDATE listings SET status='sold' WHERE id=? AND status='active'").run(listingId);
    if (!locked.changes) throw new Error("Товар уже купили.");
    db.prepare("UPDATE users SET balance=balance-? WHERE id=?").run(listing.price, buyer.id);
    db.prepare("INSERT INTO ledger(user_id,amount,type,ref) VALUES(?,?,?,?)").run(buyer.id,-listing.price,"purchase",String(listingId));
    const order = db.prepare("INSERT INTO orders(listing_id,buyer_id,seller_id,price) VALUES(?,?,?,?)").run(listingId,buyer.id,listing.seller_id,listing.price);
    db.prepare("INSERT INTO messages(order_id,sender_id,text) VALUES(?,?,?)").run(order.lastInsertRowid,buyer.id,"Заказ создан. Продавец должен передать товар.");
    return {id:order.lastInsertRowid, seller:listing.seller_id};
  });
  try {
    const out = tx();
    sendBotMessage(out.seller, `Новый заказ #${out.id}. Откройте Mini App, чтобы посмотреть заказ.`);
    res.json({ok:true,orderId:out.id});
  } catch(e) { res.status(400).json({error:e.message}); }
});

function orderAccess(req,res,id) {
  const order = db.prepare("SELECT * FROM orders WHERE id=?").get(id);
  if (!order || (order.buyer_id !== req.tgUser.id && order.seller_id !== req.tgUser.id)) {
    res.status(404).json({error:"Заказ не найден"}); return null;
  }
  return order;
}
app.get("/api/orders", auth, (req,res)=>{
  res.json(db.prepare(`
    SELECT o.*, l.title, l.game FROM orders o JOIN listings l ON l.id=o.listing_id
    WHERE o.buyer_id=? OR o.seller_id=? ORDER BY o.id DESC
  `).all(req.tgUser.id,req.tgUser.id));
});
app.get("/api/orders/:id/messages", auth, (req,res)=>{
  if (!orderAccess(req,res,req.params.id)) return;
  res.json(db.prepare("SELECT * FROM messages WHERE order_id=? ORDER BY id").all(req.params.id));
});
app.post("/api/orders/:id/messages", auth, (req,res)=>{
  if (!orderAccess(req,res,req.params.id)) return;
  const text=String(req.body?.text||"").trim();
  if (!text || text.length>2000) return res.status(400).json({error:"Сообщение пустое или слишком длинное."});
  db.prepare("INSERT INTO messages(order_id,sender_id,text) VALUES(?,?,?)").run(req.params.id,req.tgUser.id,text);
  const o=db.prepare("SELECT buyer_id,seller_id FROM orders WHERE id=?").get(req.params.id);
  const other=o.buyer_id===req.tgUser.id?o.seller_id:o.buyer_id;
  sendBotMessage(other,`Новое сообщение по заказу #${req.params.id}.`);
  res.json({ok:true});
});
app.post("/api/orders/:id/received", auth, (req,res)=>{
  const o=orderAccess(req,res,req.params.id); if(!o)return;
  if(o.buyer_id!==req.tgUser.id) return res.status(403).json({error:"Только покупатель может подтвердить получение."});
  const r=db.prepare("UPDATE orders SET status='completed', completed_at=CURRENT_TIMESTAMP WHERE id=? AND buyer_id=? AND status!='completed'").run(req.params.id,req.tgUser.id);
  if(r.changes) sendBotMessage(o.seller_id,`Покупатель подтвердил получение по заказу #${req.params.id}.`);
  res.json({ok:r.changes>0});
});
app.post("/api/orders/:id/dispute", auth, (req,res)=>{
  const o=orderAccess(req,res,req.params.id); if(!o)return;
  db.prepare("UPDATE orders SET status='dispute' WHERE id=? AND status!='completed'").run(req.params.id);
  res.json({ok:true});
});

app.post("/api/tickets", auth, (req,res)=>{
  const subject=String(req.body?.subject||"").trim(), text=String(req.body?.text||"").trim();
  if(!subject||!text)return res.status(400).json({error:"Заполните обращение."});
  const r=db.prepare("INSERT INTO tickets(user_id,subject,text) VALUES(?,?,?)").run(req.tgUser.id,subject,text);
  res.json({ok:true,id:r.lastInsertRowid});
});
app.get("/api/admin/stats", auth, (req,res)=>{
  if(!ADMIN_IDS.has(String(req.tgUser.id))) return res.status(403).json({error:"Нет доступа"});
  res.json({
    users:db.prepare("SELECT COUNT(*) c FROM users").get().c,
    listings:db.prepare("SELECT COUNT(*) c FROM listings WHERE status='active'").get().c,
    orders:db.prepare("SELECT COUNT(*) c FROM orders").get().c,
    disputes:db.prepare("SELECT COUNT(*) c FROM orders WHERE status='dispute'").get().c,
    tickets:db.prepare("SELECT COUNT(*) c FROM tickets WHERE status='open'").get().c,
    balance:db.prepare("SELECT COALESCE(SUM(balance),0) s FROM users").get().s
  });
});

app.post("/api/telegram/webhook", async (req,res)=>{
  const update=req.body;
  try {
    if (update.pre_checkout_query) {
      const q=update.pre_checkout_query;
      const p=db.prepare("SELECT * FROM payments WHERE payload=? AND status='pending'").get(q.invoice_payload);
      if (!p || p.stars !== q.total_amount || p.user_id !== q.from.id) {
        await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/answerPreCheckoutQuery`,{
          method:"POST",headers:{"content-type":"application/json"},
          body:JSON.stringify({pre_checkout_query_id:q.id,ok:false,error_message:"Платёж недействителен."})
        });
      } else {
        await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/answerPreCheckoutQuery`,{
          method:"POST",headers:{"content-type":"application/json"},
          body:JSON.stringify({pre_checkout_query_id:q.id,ok:true})
        });
      }
    }
    if (update.message?.successful_payment) {
      const sp=update.message.successful_payment;
      const p=db.prepare("SELECT * FROM payments WHERE payload=?").get(sp.invoice_payload);
      if (p && p.status==="pending" && p.stars===sp.total_amount && p.user_id===update.message.from.id) {
        const tx=db.transaction(()=>{
          const r=db.prepare("UPDATE payments SET status='paid',telegram_charge_id=? WHERE id=? AND status='pending'").run(sp.telegram_payment_charge_id,p.id);
          if(!r.changes)return;
          db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(p.stars,p.user_id);
          db.prepare("INSERT INTO ledger(user_id,amount,type,ref) VALUES(?,?,?,?)").run(p.user_id,p.stars,"topup",String(p.id));
        });
        tx();
      }
    }
  } catch(e) {}
  res.sendStatus(200);
});

app.get("*",(req,res)=>res.sendFile(process.cwd()+"/public/index.html"));
app.listen(PORT,()=>console.log(`Marketplace running on port ${PORT}`));
