# Steal an Egg Marketplace

Telegram Mini App marketplace for Roblox and Standoff 2.

## Запуск

1. Установите Node.js 20+.
2. Скопируйте `.env.example` в `.env`.
3. В `.env` укажите BOT_TOKEN вашего Telegram-бота.
4. Запустите:
   `npm install`
   `npm start`
5. Для Telegram Mini App нужен публичный HTTPS-адрес.

## Telegram Stars

Пополнение создаёт официальный Telegram invoice с валютой XTR.
Сервер обрабатывает `pre_checkout_query` и `successful_payment`.
Внутренний баланс начисляется только после подтверждённого успешного платежа и один раз.

## Важно

GitHub Pages не запускает Node.js backend. Для реального Mini App сервер должен работать на HTTPS-хостинге (или временно в публичном Codespace для тестов).

В BotFather укажите URL Mini App на публичный HTTPS-адрес сервера.
Webhook должен указывать на:
`https://ВАШ-ДОМЕН/api/telegram/webhook`

Перед продакшеном добавьте резервное копирование SQLite, rate limiting и более подробную админку.
